<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $daftarekstras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarekstra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card shadow mb-4">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse"
                                    role="button" aria-expanded="true" aria-controls="collapseCardExample">
                                    <h6 class="m-0 font-weight-bold text-primary" >
                                      <?php echo e($daftarekstra->nama); ?></h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse show" id="collapseCardExample">
                                    <div class="card-body" text-align="justify">
                                    <?php echo e($daftarekstra->deskripsi); ?>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/welcome.blade.php ENDPATH**/ ?>