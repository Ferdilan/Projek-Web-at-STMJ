<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-school"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Pengelolaan Ekstra</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <?php if(Request::segment(1) == 'welcome'): ?>
    <li class="nav-item active">
        <a class="nav-link active" href="/">
            <?php else: ?>
    <li class="nav-item">
        <a class="nav-link" href="/">
            <?php endif; ?>
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

 
    <?php if( Auth::guard('pembina')->check()): ?>
    <!-- Heading -->
    <div class="sidebar-heading">
        PEMBINA
    </div>

    <?php if(Request::segment(1) == 'Data Anggota'): ?>
    <li class="nav-item active">
        <a class="nav-link active" href="/anggotaekstra">
            <?php else: ?>
    <li class="nav-item">
        <a class="nav-link" href="/anggotaekstra">
            <?php endif; ?>
            <i class="fas fa-sign-in-alt"></i>
            <span>Data Anggota</span></a>
    </li>

    <?php if(Request::segment(1) == 'Jurnal Ekstra'): ?>
    <li class="nav-item active">
        <a class="nav-link active" href="/jurnal">
            <?php else: ?>
    <li class="nav-item">
        <a class="nav-link" href="/jurnal">
            <?php endif; ?>
            <i class="fas fa-book"></i>
            <span>Jurnal Ekstra</span></a>
    </li>

    <?php if(Request::segment(1) == 'Lihat Pendaftar'): ?>
    <li class="nav-item active">
        <a class="nav-link active" href="/pendaftaran">
            <?php else: ?>
    <li class="nav-item">
        <a class="nav-link" href="/pendaftaran">
            <?php endif; ?>
            <i class="fas fa-child"></i>
            <span>Lihat Pendaftar</span></a>
    </li>
    <?php endif; ?>
    
</ul>
<!-- End of Sidebar --><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/layouts/sidebarpembina.blade.php ENDPATH**/ ?>