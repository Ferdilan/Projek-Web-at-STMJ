
<?php $__env->startSection('content'); ?>

<div class="card">
<?php if(Auth::check() && (Auth::user()->level == 'pembina' || Auth::user()->level == 'kesiswaan')): ?>
<div class="card-header"><h2><?php echo e($titlepembina); ?><h2></div>
<?php endif; ?>
<?php if(auth()->user()->level =="siswa"): ?>
<div class="card-header"><h2><?php echo e($title); ?><h2></div>
<?php endif; ?>
<?php if(auth()->user()->level =="kesiswaan"): ?>
<div class="card-header">
<a class="btn btn-primary" href="<?php echo e(route('pendaftarexport')); ?>" role="button">Export Pendaftar Ekstra</a>
</div>
<?php endif; ?>
                        <?php if(auth()->user()->level =="siswa"): ?>
                        <div class="card-header">
                        <a class="text-danger">Anda hanya dapat melakukan pendaftaran sebanyak satu kali</a><br>
                        <a class="btn btn-primary" href="/siswa/pendaftaran/create" role="button">Pendaftaran Ekstra</a>
                        </div>
                        <?php endif; ?>
                            <div class="card-body p-0 table-responsive mt-3 ">
                            <table class="table table-striped table-hover mb-0" id="dataTable">
                                <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Nama</th>
                                            <th scope="col">Kelas</th>
                                            <th scope="col">Nomor Hp</th>
                                            <th scope="col">Alamat</th>
                                            <th scope="col">Ekstra Pertama</th>
                                            <th scope="col">Ekstra Kedua</th>
                                            <th scope="col">Ekstra Ketiga</th>
                                            <?php if(Auth::check() && (Auth::user()->level == 'pembina' || Auth::user()->level == 'kesiswaan')): ?>
                                            <th scope="col">Konfirmasi Pertama</th>
                                            <th scope="col">Konfirmasi Kedua</th>
                                            <th scope="col">Konfirmasi Ketiga</th>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->level =="kesiswaan"): ?>
                                            <th scope="col">Hapus</th>
                                            <?php endif; ?>
                                        </tr>
                                </thead>
                            
                                <tbody>
                                <?php $__currentLoopData = $pendaftars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <?php if( $pendaftar->nama == Auth::guard()->user()->nama): ?>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($pendaftar->nama); ?></td>
                                            <td><?php echo e($pendaftar->kelas); ?></td>
                                            <td><?php echo e($pendaftar->nohp); ?></td>
                                            <td><?php echo e($pendaftar->alamat); ?></td>
                                            <td><?php echo e($pendaftar->ekstra1); ?></td>
                                            <td><?php echo e($pendaftar->ekstra2); ?></td>
                                            <td><?php echo e($pendaftar->ekstra3); ?></td>
                                        <?php elseif(auth()->user()->level =="pembina"): ?>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($pendaftar->nama); ?></td>
                                            <td><?php echo e($pendaftar->kelas); ?></td>
                                            <td><?php echo e($pendaftar->nohp); ?></td>
                                            <td><?php echo e($pendaftar->alamat); ?></td>
                                            <td><?php echo e($pendaftar->ekstra1); ?></td>
                                            <td><?php echo e($pendaftar->ekstra2); ?></td>
                                            <td><?php echo e($pendaftar->ekstra3); ?></td>
                                        <?php elseif(auth()->user()->level =="kesiswaan"): ?>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($pendaftar->nama); ?></td>
                                            <td><?php echo e($pendaftar->kelas); ?></td>
                                            <td><?php echo e($pendaftar->nohp); ?></td>
                                            <td><?php echo e($pendaftar->alamat); ?></td>
                                            <td><?php echo e($pendaftar->ekstra1); ?></td>
                                            <td><?php echo e($pendaftar->ekstra2); ?></td>
                                            <td><?php echo e($pendaftar->ekstra3); ?></td>
                                        <?php endif; ?>

                                            <!-- Tabel Konfirmasi -->
                                            <!-- if untuk auth pembina dan kesiswaan -->
                                            <?php if(Auth::check() && (Auth::user()->level == 'pembina' || Auth::user()->level == 'kesiswaan')): ?>
                                            <td>
                                <?php if(auth()->user()->level =="pembina"): ?>
                                    <?php if(empty($pendaftar->konfirmasi)): ?>
                                    <form action="/pendaftaran/konfirmasi/<?php echo e($pendaftar->id); ?>" method="post"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="konfirmasi" value="Diterima">
                                        <h5><button class="badge bg-success border-0 text-white"
                                                onclick="return confirm(' Apakah Kamu Yakin Dengan Ini?')">Terima</button>
                                        </h5>
                                    </form>
                                    <form action="/pendaftaran/konfirmasi/<?php echo e($pendaftar->id); ?>" method="post"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="konfirmasi" value="Tidak Diterima">
                                        <h5><button class="badge bg-danger border-0 text-white"
                                                onclick="return confirm(' Apakah Kamu Yakin Dengan Ini?')">Tidak
                                                Diterima</button></h5>
                                    </form>
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($pendaftar->konfirmasi == "Diterima"): ?>
                                    <h5><span class="badge badge-success text-white"><?php echo e($pendaftar->konfirmasi); ?></span></h5>
                                    <?php else: ?>
                                    <h5><span class="badge badge-danger text-white"><?php echo e($pendaftar->konfirmasi); ?></span></h5>
                                    <?php endif; ?>
                                </td>
                                
                                <!-- konfirmasi2 -->
                                <td>
                                <?php if(auth()->user()->level =="pembina"): ?>
                                    <?php if(empty($pendaftar->konfirmasi2)): ?>
                                    <form action="/pendaftaran/konfirmasi2/<?php echo e($pendaftar->id); ?>" method="post"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="konfirmasi2" value="Diterima">
                                        <h5><button class="badge bg-success border-0 text-white"
                                                onclick="return confirm(' Apakah Kamu Yakin Dengan Ini?')">Terima</button>
                                        </h5>
                                    </form>
                                    <form action="/pendaftaran/konfirmasi2/<?php echo e($pendaftar->id); ?>" method="post"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="konfirmasi2" value="Tidak Diterima">
                                        <h5><button class="badge bg-danger border-0 text-white"
                                                onclick="return confirm(' Apakah Kamu Yakin Dengan Ini?')">Tidak
                                                Diterima</button></h5>
                                    </form>
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($pendaftar->konfirmasi2 == "Diterima"): ?>
                                    <h5><span class="badge badge-success text-white"><?php echo e($pendaftar->konfirmasi2); ?></span></h5>
                                    <?php else: ?>
                                    <h5><span class="badge badge-danger text-white"><?php echo e($pendaftar->konfirmasi2); ?></span></h5>
                                    <?php endif; ?>
                                    
                                </td>

                                <!-- konfirmasi3 -->
                                <td>
                                <?php if(auth()->user()->level =="pembina"): ?>
                                    <?php if(empty($pendaftar->konfirmasi3)): ?>
                                    <form action="/pendaftaran/konfirmasi3/<?php echo e($pendaftar->id); ?>" method="post"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="konfirmasi3" value="Diterima">
                                        <h5><button class="badge bg-success border-0 text-white"
                                                onclick="return confirm(' Apakah Kamu Yakin Dengan Ini?')">Terima</button>
                                        </h5>
                                    </form>
                                    <form action="/pendaftaran/konfirmasi3/<?php echo e($pendaftar->id); ?>" method="post"
                                        class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="konfirmasi3" value="Tidak Diterima">
                                        <h5><button class="badge bg-danger border-0 text-white"
                                                onclick="return confirm(' Apakah Kamu Yakin Dengan Ini?')">Tidak
                                                Diterima</button></h5>
                                    </form>
                                    <?php else: ?>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($pendaftar->konfirmasi3 == "Diterima"): ?>
                                    <h5><span class="badge badge-success text-white"><?php echo e($pendaftar->konfirmasi3); ?></span></h5>
                                    <?php else: ?>
                                    <h5><span class="badge badge-danger text-white"><?php echo e($pendaftar->konfirmasi3); ?></span></h5>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <!-- endif untuk akhiran auth kesiswan dan pembina  -->

                                <?php if(auth()->user()->level =="kesiswaan"): ?>
                                <td>
                                            <form action="/pendaftaran/<?php echo e($pendaftar->id); ?>" method="post" class="d-inline">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="badge bg-danger border-0 p-2" onclick="return confirm(' Yakin Menghapus Pendaftar? ')">Hapus</button>
                                            </form>
                                            </td>
                                <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                        
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/pendaftar/index.blade.php ENDPATH**/ ?>