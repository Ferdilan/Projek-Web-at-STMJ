<footer class="sticky-footer bg-light">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e(config('app.name')); ?> By. Ferdilan Ramadhani XII RPL B - 2023</span>
    </div>
</div>
</footer>
<?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/layouts/footer.blade.php ENDPATH**/ ?>