
<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-header"><h2><?php echo e($title); ?><h2></div>
                        <div class="card-header">
                        <a class="btn btn-primary" href="/daftarekstra/create" role="button">Tambah Ekstra</a>
                            </div>
                            <div class="card-body p-0 table-responsive mt-3">
                            <table class="table table-striped table-hover mb-0 text-alignment="justify" id="dataTable">
                                <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Nama</th>
                                            <th scope="col">Deskripsi</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $daftarekstras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarekstra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($daftarekstra->nama); ?></td>
                                            <td><?php echo e($daftarekstra->deskripsi); ?></td>
                                            <td>
                                            <a class="badge bg-warning  border- p-2 d-inline" href="/daftarekstra/<?php echo e($daftarekstra->id); ?>/edit" >Update</a>
                                            <form action="/daftarekstra/<?php echo e($daftarekstra->id); ?>" method="post" class="d-inline">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="badge bg-danger border-0 p-2 mt-3" onclick="return confirm(' Are Yout Sure Delete ')">Delete</button>
                                            </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            </div>
                            </div>
                        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/daftarekstra/index.blade.php ENDPATH**/ ?>