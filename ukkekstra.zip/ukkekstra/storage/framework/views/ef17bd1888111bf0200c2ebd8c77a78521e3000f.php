
<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-header"><h2><?php echo e($title); ?><h2></div>
                        <?php if( Str::length(Auth::guard('pembina')->user()) > 0): ?>
                        <?php if( Auth::guard('pembina')->user()->level = "pembina"): ?>
                        <div class="card-header">
                        <a class="btn btn-primary" href="/jurnal/create" role="button">Tambah Jurnal Ekstra</a>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>

                            <?php if( Str::length(Auth::guard('kesiswaan')->user()) > 0): ?>
                            <?php if( Auth::guard('kesiswaan')->user()->level = "kesiswaan"): ?>
                            <div class="card-header">
                            <a class="btn btn-primary" href="<?php echo e(route('jurnalexport')); ?>" role="button">Export Jurnal Ekstra</a>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                            <div class="card-body p-0 table-responsive mt-3" >
                            <table class="table table-striped table-hover mb-0" id="dataTable" >
                                <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Ekstra</th>
                                            <th scope="col">Pengisi Jurnal</th>
                                            <th scope="col">Tanggal</th>
                                            <th scope="col">Kegiatan</th>
                                            <?php if(auth()->user()->level =="kesiswaan"): ?>
                                            <th scope="col">Hapus</th>
                                            <?php endif; ?>
                                        </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $jurnal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnalekstra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($jurnalekstra->ekstra); ?></td>
                                            <td><?php echo e($jurnalekstra->pembina); ?></td>
                                            <td><?php echo e($jurnalekstra->tanggal); ?></td>
                                            <td><?php echo e($jurnalekstra->kegiatan); ?></td>
                                            <?php if(auth()->user()->level =="kesiswaan"): ?>
                                            <td>
                                            <form action="/jurnal/<?php echo e($jurnalekstra->id); ?>" method="post" class="d-inline">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="badge bg-danger border-0 p-2" onclick="return confirm(' Are Yout Sure Delete ')">Delete</button>
                                            </form>
                                            </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            </div>
                            </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/jurnal/index.blade.php ENDPATH**/ ?>