
<?php $__env->startSection('content'); ?>
            <a href="/anggotaekstra">
            <i class="fa fa-arrow-left mb-3 "aria-hidden="true"> Kembali</i>
            </a>
<div class="card">
<div class="card-header"><h3><?php echo e($title); ?></h3></div>
<div class="content">
            <div class="container-fluid content">
                        <div class="container  col-md-">
                        <div class="card-body col-lg-8">
                            <form action="/anggotaekstra/<?php echo e($anggotaekstra->id); ?>" method="post">
                            <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Nama</label>
                                    <input type="text" class="form-control" name="nama" id="exampleFormControlInput1" value="<?php echo e(old('nama', $anggotaekstra->nama)); ?>" placeholder="Nama" required>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Kelas</label>
                                    <input type="text" class="form-control" name="kelas" id="exampleFormControlInput1" value="<?php echo e(old('kelas', $anggotaekstra->kelas)); ?>" placeholder="Nama" required>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlTextarea1" class="form-label">Ekstra Yang Diikuti</label>
                                    <select class="form-control " id="exampleFormControlTextarea1" name="ekstra1" required>
                                    <option selected><?php echo e(old('ekstra1', $anggotaekstra->ekstra1)); ?></option>
                                    <?php $__currentLoopData = $daftarekstra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarekstra1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($daftarekstra1->nama); ?>"><?php echo e($daftarekstra1->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlTextarea1" class="form-label">Ekstra Yang Diikuti</label>
                                    <select class="form-control " id="exampleFormControlTextarea1" name="ekstra2">
                                    <option selected><?php echo e(old('ekstra2', $anggotaekstra->ekstra2)); ?></option>
                                    <?php $__currentLoopData = $daftarekstra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarekstra2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($daftarekstra2->nama); ?>"><?php echo e($daftarekstra2->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlTextarea1" class="form-label">Ekstra Yang Diikuti</label>
                                    <select class="form-control " id="exampleFormControlTextarea1" name="ekstra3">
                                    <option selected><?php echo e(old('ekstra3', $anggotaekstra->ekstra3)); ?></option>
                                    <?php $__currentLoopData = $daftarekstra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftarekstra3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($daftarekstra3->nama); ?>"><?php echo e($daftarekstra3->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>
                                </div>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                            </div>
                        </div><!-- /.container-fluid -->
                    </div>
                </div>
            </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/anggotaekstra/edit.blade.php ENDPATH**/ ?>