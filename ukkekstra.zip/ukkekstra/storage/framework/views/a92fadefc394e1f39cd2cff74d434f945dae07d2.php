
<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-header"><h2>Daftar Pembina<h2></div>
                        <div class="card-header">
                        <a class="btn btn-primary" href="/tambahpembina" role="button">Tambah Pembina</a>
                            </div>
                            <div class="card-body p-0 table-responsive mt-3">
                            <table class="table table-striped table-hover mb-0" id="dataTable">
                                <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Nama</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Password</th> 
                                            <th scope="col">Aksi</th> 
                                        </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $pembinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($pembina->nama); ?></td>
                                            <td><?php echo e($pembina->email); ?></td>
                                            <td><?php echo e($pembina->password); ?></td>
                                            <td>
                                            <form action="/daftarpembina/<?php echo e($pembina->id); ?>" method="post" class="d-inline">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="badge bg-danger border-0 p-2" onclick="return confirm(' Are Yout Sure Delete ')">Delete</button>
                                            </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            </div>
                            </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/pembina/index.blade.php ENDPATH**/ ?>