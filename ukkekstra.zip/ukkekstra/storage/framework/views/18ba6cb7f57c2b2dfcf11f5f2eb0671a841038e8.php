
<?php $__env->startSection('content'); ?>
    <div>
        <a href="/daftarpembina">
        <i class="fa fa-arrow-left mb-3"aria-hidden="true"> Kembali</i>
        </a>
    </div>
<div class="card">
<div class="card-header"><h2>Tambah Pembina<h2></div>
            <div class="card-body register-card-body">
                <form action="<?php echo e(route('simpanpembina')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="nama" placeholder="Nama"required autofocus>
                        <span class="help-block with-errors"></span>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-user"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="email" class="form-control" name="email" placeholder="Email"required autofocus>
                        <span class="help-block with-errors"></span>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" class="form-control" name="password" placeholder="Password"required autofocus>
                        <span class="help-block with-errors"></span>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!-- /.col -->
                        <div class="col-3">
                            <button type="submit" class="btn btn-primary btn-block">Tambah</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </form> 

                <br>


            </div>
            <!-- /.form-box -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukkekstra\resources\views/pembina/tambah.blade.php ENDPATH**/ ?>