<footer class="sticky-footer bg-light">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; {{ config('app.name') }} By. Ferdilan Ramadhani XII RPL B - 2023</span>
    </div>
</div>
</footer>
