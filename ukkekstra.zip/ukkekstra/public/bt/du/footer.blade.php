<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; {{ config('app.name') }} By. Grahadrian Deandratisna XII RPL B - 2022</span>
        </div>
    </div>
</footer>

