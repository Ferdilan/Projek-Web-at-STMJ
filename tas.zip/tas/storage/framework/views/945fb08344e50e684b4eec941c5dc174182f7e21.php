<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mb-3">
            <a href="<?php echo e(url('home')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
        <div class="col-md-12 mb-3">
            <a href="<?php echo e(url('crud/create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data Barang</a>
        </div>
        <div class="col-md-12">
            <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>    
                  <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Data Barang
                </div>
                <div class="card-body">
                    <table class="table">
                          <thead>
                            <tr>
                              <th scope="col">No.</th>
                              <!--th scope="col">Id</th-->
                              <th scope="col">Nama Barang</th>
                              <th scope="col">Gambar</th>
                              <th scope="col">Harga</th>
                              <th scope="col">Stok</th>
                              <th scope="col">Keterangan</th>
                              <th scope="col">Aksi</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                            $nomer = 1;
                            ?>
                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <th scope="row"><?php echo e($nomer++); ?></th>
                              <!--td><?php echo e($barang->id); ?></td-->
                              <td><?php echo e($barang->nama_barang); ?></td>
                              <td><?php echo e($barang->gambar); ?></td>
                              <td><?php echo e($barang->harga); ?></td>
                              <td><?php echo e($barang->stok); ?></td>
                              <td><?php echo e($barang->keterangan); ?></td>
                              <td>
                                  <form method="POST" action="<?php echo e(url('crud')); ?>/<?php echo e($barang->id); ?>">

                                        <a href="<?php echo e(url('crud')); ?>/<?php echo e($barang->id); ?>/edit" class="btn btn-warning btn-sm"> <i class="fa fa-edit"></i> Edit</a>

                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</button>
                                    </form>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tas\resources\views/crud/index.blade.php ENDPATH**/ ?>