<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /storage/ssd4/662/18372662/laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>