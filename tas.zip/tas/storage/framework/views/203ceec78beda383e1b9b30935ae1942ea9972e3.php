<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mb-3">
            <a href="<?php echo e(url('home')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
        <div class="col-md-12">
            <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert"></button>    
                  <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>
        </div>
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Data Pesanan
                </div>
                <div class="card-body">
                    <table class="table">
                          <thead>
                            <tr>
                              <th scope="col">No.</th>
                              <th scope="col">User Id</th>
                              <th scope="col">Nama</th>
                              <!--<th scope="col">Alamat</th>
                              <th scope="col">Nomor</th>-->
                              <th scope="col">Tanggal</th>
                              <th scope="col">Jumlah Harga</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                            $nomer = 1;
                            ?>
                            <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <th scope="row"><?php echo e($nomer++); ?></th>
                              <td><?php echo e($pesanan->user_id); ?></td>
                              <td><?php echo e($pesanan->name); ?></td>   
                              <!--<td><?php echo e($pesanan->alamat); ?></td>    
                              <td><?php echo e($pesanan->nohp); ?></td>-->                          
                              <td><?php echo e($pesanan->tanggal); ?></td>
                              <td><?php echo e($pesanan->jumlah_harga); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokotas\resources\views/daftarpesanan/index.blade.php ENDPATH**/ ?>