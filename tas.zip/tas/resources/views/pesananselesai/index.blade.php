@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 mb-3">
            <a href="{{ url('home') }}" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Kembali</a>
        </div>
        <div class="col-md-12">
            @if ($message = Session::get('success'))
              <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert"></button>    
                  <strong>{{ $message }}</strong>
              </div>
            @endif
        </div>
        
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Pesanan Selesai
                </div>
                <div class="card-body">
                    <table class="table">
                          <thead>
                            <tr>
                              <th scope="col">No.</th>
                              <th scope="col">User Id</th>
                              <th scope="col">Nama</th>
                              <th scope="col">Alamat</th>
                              <th scope="col">Kontak</th>
                              <th scope="col">Tanggal</th>
                              <th scope="col">Jumlah Harga</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                            $nomer = 1;
                            ?>
                            @foreach($pesanans as $pesanan)
                            <tr>
                              <th scope="row">{{ $nomer++ }}</th>
                              <td>{{ $pesanan->user_id }}</td>
                              <td>{{ $pesanan->name }}</td>
                              <td>{{ $pesanan->alamat }}</td>
                              <td>{{ $pesanan->nohp}}</td>          
                              <td>{{ $pesanan->tanggal }}</td>
                              <td>{{ $pesanan->jumlah_harga }}</td>
                            </tr>
                            @endforeach
                          </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection