<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $table = 'barangs';
    protected $primaryKey = 'id';

    protected $fillable = [
        'id',
        'nama_barang',
        'gambar',
        'harga',
        'stok',
        'keterangan',
    ];

    function gambar()
    {
        if ($this->gambar && file_exists(public_path('gambar/post/' . $this->gambar)))
            return asset('gambar/post/' . $this->image);
        else
            return asset('gambar/no_gambar.png');
    }

    function delete_gambar()
    {
        if ($this->gambar && file_exists(public_path('gambar/post/' . $this->gambar)))
            return unlink(public_path('gambar/post/' . $this->gambar));
    }
}
