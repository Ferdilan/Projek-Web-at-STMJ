<?php

namespace App\Http\Controllers;
use App\Pesanan;
use App\User;
use Illuminate\Http\Request;

class DaftarPesananController extends Controller
{
    public function index()
    {
        $pesanans = Pesanan::all();
        $users = User::all();
    	return view('daftarpesanan.index', compact('pesanans', 'users'));
    }
}