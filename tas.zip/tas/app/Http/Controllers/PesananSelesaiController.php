<?php

namespace App\Http\Controllers;
use App\Pesanan;
use Illuminate\Http\Request;

class PesananSelesaiController extends Controller
{
    public function index()
    {
        $pesanans = Pesanan::all();
    	return view('pesananselesai.index', compact('pesanans'));        
    }
}